odoo.define('product_herb_e.ListHerbE', function (require) {
    "use strict";
    /*---------------------------------------------------------
     * Odoo Herb-e List view
     *---------------------------------------------------------*/
    /**
     * handles editability case for lists, because it depends on form and forms already depends on lists it had to be split out
     * @namespace
     */
    var core = require('web.core')
    var ListView = require('web.ListView');
    var FormView = require('web.FormView');
    var KanbanView = require('web_kanban.KanbanView');

    var _t = core._t;

    ListView.include(/** @lends instance.web.ListView# */{

        /**
         * Extend the render_buttons function of ListView by adding event listeners
         * in the case of an editable list.
         * @return {jQuery} the rendered buttons
         */
        render_buttons: function () {
            var self = this;

            this._super.apply(this, arguments); // Sets this.$buttons
            if (this.model=='product.template' || this.model=='product.product'){
                this.$buttons.find('.o_list_button_add').off('click').on('click', function(e){
                    e.preventDefault();
                    self.do_action({
                                type: 'ir.actions.act_window',
                                res_model: 'product.new',
                                views: [[false, 'form']],
                                target: 'new',
                                name: 'Herb-e New Product Wizard'
                            });
                })
                this.$buttons.find('.o_list_button_import').hide();
            }
            /*if (add_button && (this.editable() || this.grouped)) {
                var self = this;
                this.$buttons
                    .off('click', '.o_list_button_save')
                    .on('click', '.o_list_button_save', this.proxy('save_edition'))
                    .off('click', '.o_list_button_discard')
                    .on('click', '.o_list_button_discard', function (e) {
                        e.preventDefault();
                        self.cancel_edition();
                    });
            }*/
        },
        do_activate_record: function (index, id, dataset, view) {
            console.log('T', this);
            console.log('INDEX', index);
            console.log('ID', id);
            console.log('DATASET', dataset);
            console.log('VIEW', view);
            if (this.model=='product.template' || this.model=='product.product') {
                this.dataset.ids = dataset.ids;
                this.do_action({
                            type: 'ir.actions.act_window',
                            res_model: 'product.new',
                            views: [[false, 'form']],
                            context: {'default_mode':'edit', 'default_product_select_id':id},
                            target: 'new',
                            name: 'Herb-e New Product Wizard'
                        });
                //this.select_record(index, view);
            }
            else
            {
                this._super.apply(this, arguments); // Sets this.$buttons
            }
        },
        do_delete: function (ids) {
            var self = this;
            var d_message = _t("Do you really want to delete these records?")
            if (this.model == 'res.partner'){
                d_message = _t("You are about to completely delete a customer. This may affect reporting");
            }
            else
            {
                if (this.model == 'product.product' || this.model == 'product.template') {
                    d_message = _t("You are about to completely delete a product. This will delete all the sub products");
                }
                else
                {
                    return this._super.apply(this, arguments); // Sets this.$buttons
                }
            }


            if (ids.length > 0) {
                $.prompt(d_message, {
                    buttons: { "Delete": true, "Cancel": false },
                    submit: function(e,v,m,f){
                        // use e.preventDefault() to prevent closing when needed or return false.
                        // e.preventDefault();

                        //console.log("Value clicked was: "+ v);
                        if (v) {
                            return $.when(self.dataset.unlink(ids)).done(function () {
                                _(ids).each(function (id) {
                                    self.records.remove(self.records.get(id));
                                });
                                // Hide the table if there is no more record in the dataset
                                if (self.dataset.size() === 0) {
                                    self.no_result();
                                } else {
                                    if (self.records.length === 0 && self.dataset.size() > 0) {
                                        //Trigger previous manually to navigate to previous page,
                                        //If all records are deleted on current page.
                                        self.$pager.find('ul li:first a').trigger('click');
                                    } else if (self.dataset.size() === self._limit) {
                                        //Reload listview to update current page with next page records
                                        //because pager going to be hidden if dataset.size == limit
                                        self.reload();
                                    } else {
                                        self.configure_pager(self.dataset);
                                    }
                                }
                                self.compute_aggregates();
                            });
                        }
                        else
                        {
                            return;
                        }
                    }
                });

            }
        }
    });



    KanbanView.include(/** @lends instance.web.ListView# */{

        /**
         * Extend the render_buttons function of ListView by adding event listeners
         * in the case of an editable list.
         * @return {jQuery} the rendered buttons
         */
        render_buttons: function () {
            var self = this;

            this._super.apply(this, arguments); // Sets this.$buttons
            if (this.model=='product.template' || this.model=='product.product'){
                /*this.$buttons.find('button.o-kanban-button-new').off('click').on('click', function(e){
                    e.preventDefault();
                    self.do_action({
                                type: 'ir.actions.act_window',
                                res_model: 'product.new',
                                views: [[false, 'form']],
                                target: 'new',
                                name: 'Herb-e New Product Wizard'
                            });
                })*/
                this.$buttons.find('button.o-kanban-button-new').hide();
                //this.$buttons.find('.o_list_button_import').hide();
            }
            /*if (add_button && (this.editable() || this.grouped)) {
                var self = this;
                this.$buttons
                    .off('click', '.o_list_button_save')
                    .on('click', '.o_list_button_save', this.proxy('save_edition'))
                    .off('click', '.o_list_button_discard')
                    .on('click', '.o_list_button_discard', function (e) {
                        e.preventDefault();
                        self.cancel_edition();
                    });
            }*/
        },
    });


    FormView.include({
        render_buttons: function ($node) {
            var self = this;

            this._super.apply(this, arguments); // Sets this.$buttons
            if (this.model=='product.template' || this.model=='product.product'){
                this.$buttons.find('.oe_form_button_edit').hide();
                this.$buttons.find('.oe_form_button_create').hide();
            }
            /*if (add_button && (this.editable() || this.grouped)) {
                var self = this;
                this.$buttons
                    .off('click', '.o_list_button_save')
                    .on('click', '.o_list_button_save', this.proxy('save_edition'))
                    .off('click', '.o_list_button_discard')
                    .on('click', '.o_list_button_discard', function (e) {
                        e.preventDefault();
                        self.cancel_edition();
                    });
            }*/
        },
        on_button_delete: function() {
            var d_message = _t("Do you really want to delete this record?")
            if (this.model == 'res.partner'){
                d_message = _t("You are about to completely delete a customer. This may affect reporting");
            }
            else
            {
                if (this.model == 'product.product' || this.model == 'product.template') {
                    d_message = _t("You are about to completely delete a product. This will delete all the sub products");
                }
                else
                {
                    return this._super.apply(this, arguments); // Sets this.$buttons
                }
            }
            var self = this;
            var def = $.Deferred();

            this.has_been_loaded.done(function() {
                if (self.datarecord.id) {
                    $.prompt(d_message, {
                        buttons: { "Delete": true, "Cancel": false },
                        submit: function(e,v,m,f){
                            // use e.preventDefault() to prevent closing when needed or return false.
                            // e.preventDefault();

                            //console.log("Value clicked was: "+ v);
                            if (v) {
                                self.dataset.unlink([self.datarecord.id]).done(function() {
                                    if (self.dataset.size()) {
                                        self.execute_pager_action('next');
                                    } else {
                                        self.do_action('history_back');
                                    }
                                    def.resolve();
                                });
                            }
                            else
                            {
                                $.async_when().done(function () {
                                    def.reject();
                                });
                            }
                        }
                    });

                } else {
                    $.async_when().done(function () {
                        def.reject();
                    });
                }
            });
            return def.promise();
        },
    })


});